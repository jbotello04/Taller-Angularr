import { Serie } from "./serie";

export const dataSeries = [
 new Serie(1, "Serie1", "Canal1", 1, "d1", "wp1", "p1"),
 new Serie(2, "Serie2", "Canal2", 2, "d2", "wp2", "p2"),
 new Serie(3, "Serie3", "Canal3", 3, "d3", "wp3", "p3")
];
